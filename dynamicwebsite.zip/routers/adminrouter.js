const router=require('express').Router()
const upload=require('../helper/multer')


const regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const queryc=require('../controllers/querycontroller')


router.get('/',regc.login)
router.post('/',regc.ligincheck)
router.get('/dashboard',regc.dashboard)


router.get('/banner/:message',bannerc.adminbannerselection)
router.get('/bannerupdate/:id',bannerc.adminbannerupdateform)
router.post('/bannerupdate/:id',upload.single('img'),bannerc.adminbannerupdate)


router.get('/service/:message',servicec.adminserviceselection)
router.get('/serviceadd',servicec.adminserviceaddform)
router.post('/serviceadd',upload.single('img'),servicec.adminserviceadd)
router.get('/servicedelete/:id',servicec.adminservicedelete)
router.get('/servicestatusupdate/:id',servicec.adminservicestatusupdate)


router.get('/testi/:message',testic.admintestiselection)
router.get('/testistatusupdate/:id',testic.admintestistatusupdate)
router.get('/testidelete/:id',testic.admintestidelete)


router.get('/query/:message',queryc.adminqueryselection)
router.get('/reply/:id',queryc.adminreplyform)
router.post('/reply/:id',upload.single('attechment'),queryc.adminqueryreply)
router.get('/querydelete/:id',queryc.adminquerydelete)


module.exports=router