const express=require("express")
const app=express()
require("dotenv").config()
app.use(express.urlencoded({extended:false}))
const userRouter=require('./routers/userrouter')
const adminRouter=require('./routers/adminrouter')
const mongoose=require("mongoose")
mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`)






app.use(userRouter)
app.use('/admin',adminRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(process.env.PORT,()=>{console.log(`Server is Running on Port ${process.env.PORT}`)})